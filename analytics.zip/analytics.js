document.addEventListener("DOMContentLoaded", async () => {
  try {
    const sessions = await DB.getSessions();

    if (!sessions || sessions.length === 0) {
      document.body.innerHTML += "<p>No sessions found.</p>";
      return;
    }

    // Aggregate duration by task
    const taskTotals = {};
    sessions.forEach((s) => {
      const name = s.task_name || "Working";
      taskTotals[name] = (taskTotals[name] || 0) + (s.duration || 0);
    });

    const labels = Object.keys(taskTotals);
    const values = Object.values(taskTotals).map((sec) => sec / 3600); // convert seconds → hours

    const ctx = document.getElementById("workChart").getContext("2d");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels,
        datasets: [
          {
            label: "Hours Worked",
            data: values,
            borderWidth: 1
          }
        ]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            title: { display: true, text: "Hours" }
          }
        }
      }
    });

  } catch (error) {
    console.error("Error loading sessions:", error);
    document.body.innerHTML += "<p>Error loading data.</p>";
  }
});
